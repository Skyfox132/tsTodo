import { FC } from "react";
interface ITodoList {
    value:  string,
    numberInList: number,
}

export function TodoList({name:string}) {

    

    return ( 
        <>

        </>
     );
}


